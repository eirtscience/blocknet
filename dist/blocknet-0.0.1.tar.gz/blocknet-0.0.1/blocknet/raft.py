
from .consenter import Concenter


class Raft:
    def __init__(self):
        self.concerter = Concenter()
