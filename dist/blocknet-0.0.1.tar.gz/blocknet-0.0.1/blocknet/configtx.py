
'''
@author : Fangnikoue Komabou Ayao
@email  : malevae@gmail.com
'''
import yaml


class ConfigTx:

    @classmethod
    def create(cls):
        pass
