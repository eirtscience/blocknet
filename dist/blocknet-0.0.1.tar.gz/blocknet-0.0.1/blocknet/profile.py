

from .genesis import Genesis


class Profile:

    def __init__(self):
        self.genesis = Genesis()
