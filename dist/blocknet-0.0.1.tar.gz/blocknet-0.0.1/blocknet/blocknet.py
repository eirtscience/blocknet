class BlockNet:
    version = "0.0.1"
