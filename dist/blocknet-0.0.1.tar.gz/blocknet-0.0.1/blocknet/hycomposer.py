
class HyperledgerComposer:

    def __init__(self, install=False, port=8092):
        self.install = install
        self.port = port
