
from .broker import Broker


class Kafka:
    def __init__(self):
        self.broker = Broker()
