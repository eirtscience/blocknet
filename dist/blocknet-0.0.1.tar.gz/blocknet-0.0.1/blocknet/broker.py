
from .server import Server


class Broker(Server):
    def __init__(self):
        pass
